﻿namespace IOOP_Assignment
{
    partial class Buyer_Order_History
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.box_History = new System.Windows.Forms.ListBox();
            this.btn_Back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // box_History
            // 
            this.box_History.FormattingEnabled = true;
            this.box_History.ItemHeight = 18;
            this.box_History.Location = new System.Drawing.Point(49, 52);
            this.box_History.Name = "box_History";
            this.box_History.Size = new System.Drawing.Size(410, 184);
            this.box_History.TabIndex = 0;
            this.box_History.SelectedIndexChanged += new System.EventHandler(this.box_History_SelectedIndexChanged);
            // 
            // btn_Back
            // 
            this.btn_Back.Location = new System.Drawing.Point(234, 324);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(83, 62);
            this.btn_Back.TabIndex = 1;
            this.btn_Back.Text = "Back to Menu";
            this.btn_Back.UseVisualStyleBackColor = true;
            // 
            // Buyer_Order_History
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(557, 427);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.box_History);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Buyer_Order_History";
            this.Text = "Order History";
            this.Load += new System.EventHandler(this.Buyer_Order_History_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox box_History;
        private System.Windows.Forms.Button btn_Back;
    }
}