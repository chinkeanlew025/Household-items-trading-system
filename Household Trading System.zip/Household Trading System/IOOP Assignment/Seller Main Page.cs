﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment
{
    public partial class Seller_Main_Page : Form
    {
        public Seller_Main_Page()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainMenu nf = new MainMenu();
            this.Hide();
            nf.ShowDialog();
        }

        private void updateAccountInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Seller_Update nff = new Seller_Update();
            nff.ShowDialog();
        }

        private void Seller_Main_Page_Load(object sender, EventArgs e)
        {
            label1.Text = "Welcome back, " + MainMenu._Name + "!";
            CredBalance.Text = "RM" + MainMenu.Credit_Bal.ToString();
            label4.Text = MainMenu.Seller_Rating + "/10";
        }

        private void TopUp_btn_Click(object sender, EventArgs e)
        {
            Top_Up_Credits nff = new Top_Up_Credits();
            nff.ShowDialog();
        }

        private void MyItems_btn_Click(object sender, EventArgs e)
        {
            Seller_Items nf = new Seller_Items();
            this.Hide();
            nf.ShowDialog();
        }
    }
}
