﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment
{
   
    public partial class MainMenu : Form
    {
        private OleDbConnection connection = new OleDbConnection();

        public static string Login;
        public static string _Name;
        public static decimal Credit_Bal;
        public static string Buyer_Rating;
        public static string Seller_Rating;

        public MainMenu()
        {
            InitializeComponent();
            connection.ConnectionString = "Provider=Microsoft.JET.OLEDB.4.0;Data Source=PrelovedHouseholdItemsTrading.mdb;";
        }

        public void MainMenu_Load(object sender, EventArgs e)
        {
            connection.Open();
            string username = UName_Box.Text;
        }

        public void Login_Button_Click(object sender, EventArgs e)
        {


            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = connection;
            cmd.CommandText = "select * from Users where Username='" + UName_Box.Text + "' and Password='" + Pwd_Box.Text + "'";
            OleDbDataReader reader = cmd.ExecuteReader();


            if (reader.Read() == true)
            {
                Login = UName_Box.Text;
                _Name = reader[0].ToString();
                Credit_Bal = reader.GetDecimal(6);
                Buyer_Rating = reader[7].ToString();
                Seller_Rating = reader[8].ToString();

                if (reader.GetString(5) == "Buyer")
                { 
                    MessageBox.Show("Login successful!");
                    Buyer_Main_Page f1 = new Buyer_Main_Page();
                    this.Hide();
                    f1.ShowDialog();
                    connection.Close();
                }
                else if (reader.GetString(5) == "Seller")
                {
                    MessageBox.Show("Login successful!");
                    Seller_Main_Page f2 = new Seller_Main_Page();
                    this.Hide();
                    f2.ShowDialog();
                    connection.Close();
                }
                else if (reader.GetString(5) == "Admin")
                {
                    MessageBox.Show("Login successful!");
                    Admin_Page f3 = new Admin_Page();
                    this.Hide();
                    f3.ShowDialog();
                    connection.Close();
                }

            }
            else
            {
                MessageBox.Show("Invalid Username/Password");
            }
           

        }

        private void Reg_Button_Click(object sender, EventArgs e)
        {
            Register_New_User nf = new Register_New_User();
            this.Hide();
            connection.Close();
            nf.ShowDialog();
        }





    }



}

