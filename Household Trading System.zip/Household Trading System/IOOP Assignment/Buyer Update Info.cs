﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment
{
    public partial class Buyer_Update_Info : Form
    {
        private OleDbConnection connection = new OleDbConnection();
        string username = MainMenu.Login;


        public Buyer_Update_Info()
        {
            InitializeComponent();
            connection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=VelvetGoods2.mdb;";

        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if(NewUser_box!=null||NewEmail_box!=null || NewPwd_box != null || NewName_box != null || ContNumb_box != null)
            {
                connection.Open();
                OleDbCommand cmd = new OleDbCommand();
                cmd.Connection = connection;
                cmd.CommandText = "update Users set [Username] ='" + NewUser_box.Text + "', [Password] ='" + NewPwd_box.Text + "', [Name] = '" + NewName_box.Text + "', [Email] = '" + NewEmail_box.Text + "', Contact_num = '" + ContNumb_box.Text + "' where [Username] = '"+username+"'";
                cmd.ExecuteNonQuery();
                MessageBox.Show("Your details have been successfully updated!");
                connection.Close();

            }   
            else
            {
                MessageBox.Show("Please do not leave any columns empty.");
            }
        }

        private void Buyer_Update_Info_Load(object sender, EventArgs e)
        {
            connection.Open();
  

            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = connection;
            cmd.CommandText = "select * from Users where Username='" + username + "'";
            OleDbDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                NewUser_box.Text = rdr[3].ToString();
                NewPwd_box.Text = rdr[4].ToString();
                NewName_box.Text = rdr[0].ToString();
                ContNumb_box.Text = rdr[2].ToString();
                NewEmail_box.Text = rdr[1].ToString();
            }
            connection.Close();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
