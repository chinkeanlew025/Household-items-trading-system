﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment
{
    public partial class Admin_Purchase : Form
    {
        OleDbConnection connection = new OleDbConnection();
        public Admin_Purchase()
        {
            InitializeComponent();
            connection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=VelvetGoods2.mdb;";
        }

        private void Admin_Purchase_Load(object sender, EventArgs e)
        {
            connection.Open();
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = connection;
            cmd.CommandText ="select * from Products_Purchased";
            OleDbDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                string Prod_ID = rdr.GetString(0);
                string Prod_Name = rdr.GetString(1);
                decimal Prod_Price = rdr.GetDecimal(2);
                string Purchase_Date = rdr.GetDateTime(5).ToShortDateString();
                box_Purchase.Items.Add(Prod_ID + "\t" + Prod_Name.PadRight(16) + "\t\tRM" + Prod_Price.ToString("0.00") + "\t\t" + Purchase_Date);
            }
            connection.Close();
        }

        private void box_Purchase_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                string Selecteditem = box_Purchase.SelectedItem.ToString().Substring(0, 5);

                connection.Open();
                OleDbCommand cmd = new OleDbCommand();
                cmd.Connection = connection;
                cmd.CommandText = "select * from Products_Purchased where Product_ID='" + Selecteditem + "'";
                OleDbDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    box_Seller.Text = rdr.GetString(3);
                    box_Buyer.Text = rdr.GetString(4);
                }
                connection.Close();
            }
            catch
            {

            }
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
