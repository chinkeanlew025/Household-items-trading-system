﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment
{
    public partial class Admin_Selling : Form
    {
        OleDbConnection connection = new OleDbConnection();
        public Admin_Selling()
        {
            InitializeComponent();
            connection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=VelvetGoods2.mdb;";
        }

        private void box_Sale_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                string Selecteditem = box_Sale.SelectedItem.ToString().Substring(0, 5);

                connection.Open();
                OleDbCommand cmd = new OleDbCommand();
                cmd.Connection = connection;
                cmd.CommandText = "select * from Products where Product_ID='" + Selecteditem + "'";
                OleDbDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    box_Descr.Text = rdr.GetString(2);
                }
                connection.Close();
            }
            catch
            {

            }
        }

        private void Admin_Selling_Load(object sender, EventArgs e)
        {
            connection.Open();
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = connection;
            cmd.CommandText = "select * from Products where Status = 'Selling'";
            OleDbDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                string Prod_ID = rdr.GetString(0);
                string Prod_Name = rdr.GetString(1);
                decimal Prod_Price = rdr.GetDecimal(3);
                string Prod_Seller = rdr.GetString(4);
                box_Sale.Items.Add(Prod_ID + "\t" + Prod_Name.PadRight(16) + "\t\tRM" + Prod_Price.ToString("0.00") + "\t" + Prod_Seller);
            }
            connection.Close();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void box_Descr_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}