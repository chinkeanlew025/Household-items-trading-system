﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment
{
    public partial class Buyer_Main_Page : Form
    {
        public Buyer_Main_Page()
        {
            InitializeComponent();
        }

        private void optionsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void updateAccountInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Buyer_Update_Info nf = new Buyer_Update_Info();
            nf.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Prod_btn_Click(object sender, EventArgs e)
        {
            Products_Page nf = new Products_Page();
            this.Hide();
            nf.ShowDialog();
            
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainMenu nf = new MainMenu();
            this.Hide();
            nf.ShowDialog();
        }

        private void Buyer_Main_Page_Load(object sender, EventArgs e)
        {
            label2.Text = MainMenu.Buyer_Rating + "/10";
            label1.Text = "Welcome back, " + MainMenu._Name + "!";
        }

        private void Order_btn_Click(object sender, EventArgs e)
        {
            Buyer_Order_History nf = new Buyer_Order_History();
            this.Close();
            nf.ShowDialog();
        }
    }
}
