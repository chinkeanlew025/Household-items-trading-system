﻿namespace IOOP_Assignment
{
    partial class Add_New_Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.box_ProdName = new System.Windows.Forms.TextBox();
            this.box_Price = new System.Windows.Forms.TextBox();
            this.box_Descr = new System.Windows.Forms.TextBox();
            this.box_Category = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_Add = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // box_ProdName
            // 
            this.box_ProdName.Location = new System.Drawing.Point(138, 53);
            this.box_ProdName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.box_ProdName.Name = "box_ProdName";
            this.box_ProdName.Size = new System.Drawing.Size(282, 37);
            this.box_ProdName.TabIndex = 0;
            // 
            // box_Price
            // 
            this.box_Price.Location = new System.Drawing.Point(503, 48);
            this.box_Price.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.box_Price.Name = "box_Price";
            this.box_Price.Size = new System.Drawing.Size(112, 37);
            this.box_Price.TabIndex = 1;
            this.box_Price.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // box_Descr
            // 
            this.box_Descr.Location = new System.Drawing.Point(127, 134);
            this.box_Descr.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.box_Descr.Multiline = true;
            this.box_Descr.Name = "box_Descr";
            this.box_Descr.Size = new System.Drawing.Size(311, 88);
            this.box_Descr.TabIndex = 2;
            // 
            // box_Category
            // 
            this.box_Category.FormattingEnabled = true;
            this.box_Category.Items.AddRange(new object[] {
            "Bedroom",
            "Bathroom",
            "Kitchen",
            "Electronics"});
            this.box_Category.Location = new System.Drawing.Point(503, 181);
            this.box_Category.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.box_Category.Name = "box_Category";
            this.box_Category.Size = new System.Drawing.Size(136, 27);
            this.box_Category.TabIndex = 3;
            this.box_Category.Text = "Please choose..";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 19);
            this.label1.TabIndex = 4;
            this.label1.Text = "Product Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 158);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 38);
            this.label2.TabIndex = 5;
            this.label2.Text = "Product\r\nDescription:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(508, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 19);
            this.label3.TabIndex = 6;
            this.label3.Text = "Selling Price:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(508, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 19);
            this.label4.TabIndex = 7;
            this.label4.Text = "Category of Item:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(123, 226);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(323, 57);
            this.label5.TabIndex = 8;
            this.label5.Text = "Please write a short description that Includes\r\n how old it is and what condition" +
    "the item is in. \r\nThis will help you sell your item better.\r\n";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(470, 64);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 19);
            this.label6.TabIndex = 9;
            this.label6.Text = "RM";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // btn_Add
            // 
            this.btn_Add.Location = new System.Drawing.Point(283, 316);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(209, 43);
            this.btn_Add.TabIndex = 10;
            this.btn_Add.Text = "ADD ITEM";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // Add_New_Product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 400);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.box_Category);
            this.Controls.Add(this.box_Descr);
            this.Controls.Add(this.box_Price);
            this.Controls.Add(this.box_ProdName);
            this.Font = new System.Drawing.Font("Adobe Fan Heiti Std B", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Add_New_Product";
            this.Text = "New Item";
            this.Load += new System.EventHandler(this.Add_New_Product_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox box_ProdName;
        private System.Windows.Forms.TextBox box_Price;
        private System.Windows.Forms.TextBox box_Descr;
        private System.Windows.Forms.ComboBox box_Category;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_Add;
    }
}