﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment
{
    public partial class Register_New_User : Form
    {
        private OleDbConnection connection = new OleDbConnection();
        private OleDbCommand cmd = new OleDbCommand();
        

        public Register_New_User()
        {
            InitializeComponent();
            connection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=VelvetGoods2.mdb;";
            connection.Open();
            cmd.Connection = connection;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(AccType_box.SelectedItem.ToString());
        }

        private void NewRegister_btn_Click(object sender, EventArgs e)
        {
            {
                cmd.CommandText = "select * from Users where Username='" + NewUser_box.Text + "' or Email='" + NewEmail_box.Text + "' or Name='" + NewName_box.Text + "' or Contact_num='" + ContNumb_box.Text + "'";
                OleDbDataReader rdr = cmd.ExecuteReader();
              

                if (rdr.Read() == true)
                {
                    MessageBox.Show("This person is already registered in our record. Please try again.");
                }
                else
                {
                    connection.Close();
                    Registration();
                }
            } 

        }

        private void Registration()
        {
            connection.Open();
            string AccType = AccType_box.SelectedItem.ToString();
            cmd.CommandText = "insert into Users([Name],Email,Contact_num,[Username],[Password],Account_type) values ('" + NewName_box.Text + "','" + NewEmail_box.Text + "','" + ContNumb_box.Text + "','" + NewUser_box.Text + "','" + NewPwd_box.Text + "','" + AccType + "')";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Registration Successful! \nPlease return to Main Menu to login.");
            connection.Close();
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            MainMenu nf = new MainMenu();
            this.Hide();
            nf.ShowDialog();
        }

        private void Register_New_User_Load(object sender, EventArgs e)
        {

        }
    }
}
