﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment
{
    public partial class Seller_Items : Form
    {
        OleDbConnection connection = new OleDbConnection();
        public Seller_Items()
        {
            InitializeComponent();
            connection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=VelvetGoods2.mdb;";
        }

        private void Seller_Items_Load(object sender, EventArgs e)
        {
            btn_Remove.Enabled = false;
            btn_Bad.Enabled = false;
            btn_Good.Enabled = false;
            btn_Email.Enabled = false;

            connection.Open();
            OleDbCommand cmd = new OleDbCommand();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            cmd.Connection = connection;
            cmd.CommandText = "select * from Products where Seller_Username='" + MainMenu.Login + "' and Status='Selling'";
            OleDbDataReader rdr = cmd.ExecuteReader();
            while(rdr.Read())
            {
                string Prod_ID = rdr.GetString(0);
                string Prod_Name = rdr.GetString(1);
                decimal Prod_Price = rdr.GetDecimal(3);
                decimal Success_Fee = rdr.GetDecimal(5);
                listBox1.Items.Add(Prod_ID + "\t" + Prod_Name.PadRight(16) + "\t\tRM" + Prod_Price.ToString("0.00") + "\t\tRM" + Success_Fee.ToString("0.00"));
            }
            command.CommandText = "select * from Products_Purchased where Seller_Username = '" + MainMenu.Login + "'";
            OleDbDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string Prod_ID_ = reader.GetString(0);
                string Prod_Name_ = reader.GetString(1);
                decimal Prod_Price_ = reader.GetDecimal(2);
                string Buyer_Name = reader.GetString(4);
                string Date_Purchase = reader.GetDateTime(5).ToShortDateString();
                listBox2.Items.Add(Buyer_Name.PadRight(15) + "\t" + Prod_ID_ + "\t" + Prod_Name_.PadRight(16) + "\t\tRM" + Prod_Price_.ToString("0.00") + "\t" + Date_Purchase);
            }
            connection.Close();



        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            Add_New_Product nf = new Add_New_Product();
            nf.ShowDialog();
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listBox2.SelectedItem != null)
            {
                btn_Good.Enabled = true;
                btn_Bad.Enabled = true;
                
            }
            
        }

        private void btn_Good_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string SelectedItem = listBox2.SelectedItems.ToString().Substring(0, 12);
                OleDbCommand cmd = new OleDbCommand();
                cmd.Connection = connection;
                cmd.CommandText = "update Users set Trusted_Buyer = Trusted_Buyer + 1 where [Username]='" + SelectedItem + "'";
                cmd.ExecuteNonQuery();
                MessageBox.Show("Thanks for rating!");
            }
            catch
            {

            }
        }

        private void btn_Bad_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string SelectedItem = listBox2.SelectedItems.ToString().Substring(0, 12);
                OleDbCommand cmd = new OleDbCommand();
                cmd.Connection = connection;
                cmd.CommandText = "update Users set Trusted_Buyer = Trusted_Buyer - 1 where [Username]='" + SelectedItem + "'";
                cmd.ExecuteNonQuery();
                MessageBox.Show("Thanks for rating!");
            }
            catch
            {

            }
        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            DialogResult confirmation = MessageBox.Show("Are you sure you want to remove this listing?","Really?", MessageBoxButtons.YesNo);
            if (confirmation == DialogResult.Yes)
            {
                try
                {
                    connection.Open();
                    string SelectedItem = listBox1.SelectedItems.ToString().Substring(0, 5);
                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "delete from Products where Product_ID = '" + SelectedItem + "'";
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record has been removed");

                    listBox1.Items.Clear();
                    Seller_Items_Load(null, null);
                }
                catch
                {

                }
            }
            else if(confirmation == DialogResult.No)
            {

            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listBox1.SelectedItems != null)
            {
                btn_Remove.Enabled = true;
            }
        }
    }
}
