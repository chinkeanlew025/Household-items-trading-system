﻿namespace IOOP_Assignment
{
    partial class Seller_Update
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NewEmail_box = new System.Windows.Forms.TextBox();
            this.ContNumb_box = new System.Windows.Forms.TextBox();
            this.NewUser_box = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_Back = new System.Windows.Forms.Button();
            this.btn_Update = new System.Windows.Forms.Button();
            this.NewPwd_box = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // NewEmail_box
            // 
            this.NewEmail_box.Location = new System.Drawing.Point(596, 30);
            this.NewEmail_box.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.NewEmail_box.Name = "NewEmail_box";
            this.NewEmail_box.Size = new System.Drawing.Size(272, 37);
            this.NewEmail_box.TabIndex = 19;
            // 
            // ContNumb_box
            // 
            this.ContNumb_box.Location = new System.Drawing.Point(596, 85);
            this.ContNumb_box.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ContNumb_box.Name = "ContNumb_box";
            this.ContNumb_box.Size = new System.Drawing.Size(192, 37);
            this.ContNumb_box.TabIndex = 18;
            // 
            // NewUser_box
            // 
            this.NewUser_box.Location = new System.Drawing.Point(125, 30);
            this.NewUser_box.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.NewUser_box.Name = "NewUser_box";
            this.NewUser_box.Size = new System.Drawing.Size(300, 37);
            this.NewUser_box.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(531, 33);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 19);
            this.label6.TabIndex = 15;
            this.label6.Text = "E-mail :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(460, 88);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(130, 19);
            this.label5.TabIndex = 14;
            this.label5.Text = "Contact Number :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 19);
            this.label1.TabIndex = 12;
            this.label1.Text = "Username :";
            // 
            // btn_Back
            // 
            this.btn_Back.Location = new System.Drawing.Point(491, 157);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(89, 46);
            this.btn_Back.TabIndex = 31;
            this.btn_Back.Text = "Back to Menu";
            this.btn_Back.UseVisualStyleBackColor = true;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // btn_Update
            // 
            this.btn_Update.Location = new System.Drawing.Point(351, 160);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(89, 46);
            this.btn_Update.TabIndex = 30;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = true;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // NewPwd_box
            // 
            this.NewPwd_box.Location = new System.Drawing.Point(125, 85);
            this.NewPwd_box.Name = "NewPwd_box";
            this.NewPwd_box.Size = new System.Drawing.Size(267, 37);
            this.NewPwd_box.TabIndex = 33;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 19);
            this.label2.TabIndex = 32;
            this.label2.Text = "Password :";
            // 
            // Seller_Update
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(926, 224);
            this.Controls.Add(this.NewPwd_box);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.NewEmail_box);
            this.Controls.Add(this.ContNumb_box);
            this.Controls.Add(this.NewUser_box);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Adobe Fan Heiti Std B", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Seller_Update";
            this.Text = "Update Account Information";
            this.Load += new System.EventHandler(this.Seller_Update_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox NewEmail_box;
        private System.Windows.Forms.TextBox ContNumb_box;
        private System.Windows.Forms.TextBox NewUser_box;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.TextBox NewPwd_box;
        private System.Windows.Forms.Label label2;
    }
}