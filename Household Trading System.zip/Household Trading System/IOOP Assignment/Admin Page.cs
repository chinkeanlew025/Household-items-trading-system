﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment
{
    public partial class Admin_Page : Form
    {
        public Admin_Page()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainMenu nf = new MainMenu();
            this.Hide();
            nf.ShowDialog();
        }

        private void updatePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Admin_Update_Info nff = new Admin_Update_Info();
            nff.ShowDialog();
        }

        private void AllSelling_btn_Click(object sender, EventArgs e)
        {
            Admin_Selling nf = new Admin_Selling();
            nf.ShowDialog();
        }

        private void AllBuying_btn_Click(object sender, EventArgs e)
        {
            Admin_Purchase nf = new Admin_Purchase();
            nf.ShowDialog();
        }

        private void SuccFees_btn_Click(object sender, EventArgs e)
        {
            Admin_Success_Fees nf = new Admin_Success_Fees();
            nf.ShowDialog();
        }
    }
}
