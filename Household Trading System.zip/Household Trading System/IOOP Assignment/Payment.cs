﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment
{
    public partial class Payment : Form
    {
        OleDbConnection connection = new OleDbConnection();
        public Payment()
        {
            InitializeComponent();
            connection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=VelvetGoods2.mdb;";
        }

        private void Payment_Load(object sender, EventArgs e)
        {
            lbl_Product.Text = Order.Order_Name;
            lbl_Seller.Text = Order.Seller;
            box_Price.Text = Order.Order_Price.ToString("RM" + "0.00");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string date_purchased = DateTime.Now.ToString("dd/MM/yyyy");
            connection.Open();
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = connection;
            cmd.CommandText = "update Products set Status ='Purchased' where Product_ID='" + Order.Buy_ID + "'";
            cmd.CommandText = "insert into Products_Purchased values('" + Order.Buy_ID + "', '" + Order.Order_Name + "','" + Order.Order_Price + "','" + Order.Seller + "','" + MainMenu.Login + "','" + date_purchased + "'";
            OleDbDataReader rdr = cmd.ExecuteReader();
            rdr.Read();
            cmd.ExecuteNonQuery();
            MessageBox.Show("Thank you for your purchase! \nThe seller will contact you through e-mail to arrange shipping. \n\n Have a nice day!");
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            Products_Page nf = new Products_Page();
            this.Hide();
            nf.ShowDialog();
        }

        private void lbl_Product_Click(object sender, EventArgs e)
        {

        }
    }
}
