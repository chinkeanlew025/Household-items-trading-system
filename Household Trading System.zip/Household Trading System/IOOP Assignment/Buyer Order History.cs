﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment
{
    public partial class Buyer_Order_History : Form
    {
        OleDbConnection connection = new OleDbConnection();
        public Buyer_Order_History()
        {
            InitializeComponent();
            connection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=VelvetGoods2.mdb;";
        }

        private void Buyer_Order_History_Load(object sender, EventArgs e)
        {
            connection.Open();
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = connection;
            cmd.CommandText = "select * from Products_Purchased where Buyer_Username = '"+MainMenu.Login+"'";
            OleDbDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                string Prod_ID = rdr.GetString(0);
                string Prod_Name = rdr.GetString(1);
                decimal Prod_Price = rdr.GetDecimal(2);
                string Seller = rdr.GetString(3);
                string Purchase_Date = rdr.GetDateTime(5).ToShortDateString();
                box_History.Items.Add(Purchase_Date +"\t" + Prod_ID + "\t" + Prod_Name.PadRight(16) + "\t\tRM" + Prod_Price.ToString("0.00"));
            }
            connection.Close();
        }

        private void box_History_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
