﻿namespace IOOP_Assignment
{
    partial class Products_Page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ProdList = new System.Windows.Forms.ListBox();
            this.rbtn_Bedroom = new System.Windows.Forms.RadioButton();
            this.rbtn_Bathroom = new System.Windows.Forms.RadioButton();
            this.rbtn_Kitchen = new System.Windows.Forms.RadioButton();
            this.rbtn_Electronics = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtn_All = new System.Windows.Forms.RadioButton();
            this.btn_Buy = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Descrip_label = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.backToMenuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ProdList
            // 
            this.ProdList.Font = new System.Drawing.Font("Adobe Fan Heiti Std B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.ProdList.FormattingEnabled = true;
            this.ProdList.ItemHeight = 25;
            this.ProdList.Location = new System.Drawing.Point(21, 61);
            this.ProdList.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProdList.Name = "ProdList";
            this.ProdList.Size = new System.Drawing.Size(544, 229);
            this.ProdList.TabIndex = 0;
            this.ProdList.SelectedIndexChanged += new System.EventHandler(this.ProdList_SelectedIndexChanged);
            // 
            // rbtn_Bedroom
            // 
            this.rbtn_Bedroom.AutoSize = true;
            this.rbtn_Bedroom.Location = new System.Drawing.Point(26, 75);
            this.rbtn_Bedroom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtn_Bedroom.Name = "rbtn_Bedroom";
            this.rbtn_Bedroom.Size = new System.Drawing.Size(94, 23);
            this.rbtn_Bedroom.TabIndex = 2;
            this.rbtn_Bedroom.TabStop = true;
            this.rbtn_Bedroom.Text = "Bedroom";
            this.rbtn_Bedroom.UseVisualStyleBackColor = true;
            this.rbtn_Bedroom.CheckedChanged += new System.EventHandler(this.rbtn_Bedroom_CheckedChanged);
            // 
            // rbtn_Bathroom
            // 
            this.rbtn_Bathroom.AutoSize = true;
            this.rbtn_Bathroom.Location = new System.Drawing.Point(26, 118);
            this.rbtn_Bathroom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtn_Bathroom.Name = "rbtn_Bathroom";
            this.rbtn_Bathroom.Size = new System.Drawing.Size(100, 23);
            this.rbtn_Bathroom.TabIndex = 3;
            this.rbtn_Bathroom.TabStop = true;
            this.rbtn_Bathroom.Text = "Bathroom";
            this.rbtn_Bathroom.UseVisualStyleBackColor = true;
            this.rbtn_Bathroom.CheckedChanged += new System.EventHandler(this.rbtn_Bathroom_CheckedChanged);
            // 
            // rbtn_Kitchen
            // 
            this.rbtn_Kitchen.AutoSize = true;
            this.rbtn_Kitchen.Location = new System.Drawing.Point(26, 161);
            this.rbtn_Kitchen.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtn_Kitchen.Name = "rbtn_Kitchen";
            this.rbtn_Kitchen.Size = new System.Drawing.Size(82, 23);
            this.rbtn_Kitchen.TabIndex = 4;
            this.rbtn_Kitchen.TabStop = true;
            this.rbtn_Kitchen.Text = "Kitchen";
            this.rbtn_Kitchen.UseVisualStyleBackColor = true;
            this.rbtn_Kitchen.CheckedChanged += new System.EventHandler(this.rbtn_Kitchen_CheckedChanged);
            // 
            // rbtn_Electronics
            // 
            this.rbtn_Electronics.AutoSize = true;
            this.rbtn_Electronics.Location = new System.Drawing.Point(26, 201);
            this.rbtn_Electronics.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtn_Electronics.Name = "rbtn_Electronics";
            this.rbtn_Electronics.Size = new System.Drawing.Size(104, 23);
            this.rbtn_Electronics.TabIndex = 5;
            this.rbtn_Electronics.TabStop = true;
            this.rbtn_Electronics.Text = "Electronics";
            this.rbtn_Electronics.UseVisualStyleBackColor = true;
            this.rbtn_Electronics.CheckedChanged += new System.EventHandler(this.rbtn_Electronics_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtn_All);
            this.groupBox1.Controls.Add(this.rbtn_Electronics);
            this.groupBox1.Controls.Add(this.rbtn_Kitchen);
            this.groupBox1.Controls.Add(this.rbtn_Bathroom);
            this.groupBox1.Controls.Add(this.rbtn_Bedroom);
            this.groupBox1.Location = new System.Drawing.Point(600, 47);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(150, 243);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Categories";
            // 
            // rbtn_All
            // 
            this.rbtn_All.AutoSize = true;
            this.rbtn_All.Location = new System.Drawing.Point(26, 35);
            this.rbtn_All.Name = "rbtn_All";
            this.rbtn_All.Size = new System.Drawing.Size(48, 23);
            this.rbtn_All.TabIndex = 12;
            this.rbtn_All.TabStop = true;
            this.rbtn_All.Text = "All";
            this.rbtn_All.UseVisualStyleBackColor = true;
            this.rbtn_All.CheckedChanged += new System.EventHandler(this.rbtn_All_CheckedChanged);
            // 
            // btn_Buy
            // 
            this.btn_Buy.BackColor = System.Drawing.Color.Firebrick;
            this.btn_Buy.Font = new System.Drawing.Font("Adobe Gothic Std B", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_Buy.ForeColor = System.Drawing.Color.Yellow;
            this.btn_Buy.Location = new System.Drawing.Point(610, 306);
            this.btn_Buy.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Buy.Name = "btn_Buy";
            this.btn_Buy.Size = new System.Drawing.Size(120, 67);
            this.btn_Buy.TabIndex = 9;
            this.btn_Buy.Text = "BUY";
            this.btn_Buy.UseVisualStyleBackColor = false;
            this.btn_Buy.Click += new System.EventHandler(this.btn_Buy_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 306);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 19);
            this.label1.TabIndex = 10;
            this.label1.Text = "Product Description: ";
            // 
            // Descrip_label
            // 
            this.Descrip_label.AutoSize = true;
            this.Descrip_label.Location = new System.Drawing.Point(17, 339);
            this.Descrip_label.Name = "Descrip_label";
            this.Descrip_label.Size = new System.Drawing.Size(486, 19);
            this.Descrip_label.TabIndex = 11;
            this.Descrip_label.Text = "[Product Description displays here when product is selected in list box]";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 19);
            this.label2.TabIndex = 12;
            this.label2.Text = "Item Code";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(109, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 19);
            this.label3.TabIndex = 13;
            this.label3.Text = "Item Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(332, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 19);
            this.label4.TabIndex = 14;
            this.label4.Text = "Price";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(453, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 19);
            this.label5.TabIndex = 15;
            this.label5.Text = "Seller";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.backToMenuToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(772, 28);
            this.menuStrip1.TabIndex = 16;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // backToMenuToolStripMenuItem
            // 
            this.backToMenuToolStripMenuItem.Name = "backToMenuToolStripMenuItem";
            this.backToMenuToolStripMenuItem.Size = new System.Drawing.Size(111, 24);
            this.backToMenuToolStripMenuItem.Text = "Back to Menu";
            this.backToMenuToolStripMenuItem.Click += new System.EventHandler(this.backToMenuToolStripMenuItem_Click);
            // 
            // Products_Page
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(772, 396);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Descrip_label);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Buy);
            this.Controls.Add(this.ProdList);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Adobe Fan Heiti Std B", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Products_Page";
            this.Text = "Products";
            this.Load += new System.EventHandler(this.Products_Page_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.RadioButton rbtn_Bedroom;
        private System.Windows.Forms.RadioButton rbtn_Bathroom;
        private System.Windows.Forms.RadioButton rbtn_Kitchen;
        private System.Windows.Forms.RadioButton rbtn_Electronics;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_Buy;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Descrip_label;
        private System.Windows.Forms.RadioButton rbtn_All;
        public System.Windows.Forms.ListBox ProdList;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem backToMenuToolStripMenuItem;
    }
}