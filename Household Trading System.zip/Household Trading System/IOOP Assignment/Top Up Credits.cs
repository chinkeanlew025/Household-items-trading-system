﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment
{
    public partial class Top_Up_Credits : Form
    {
        private OleDbConnection connection = new OleDbConnection();


        public Top_Up_Credits()
        {
            InitializeComponent();
            connection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=VelvetGoods2.mdb;";
        }

        private void Top_Up_Credits_Load(object sender, EventArgs e)
        {
            connection.Open();
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = connection;
            cmd.CommandText = "select * from Users where Username='" + MainMenu.Login + "'";
            OleDbDataReader rdr = cmd.ExecuteReader();
            rdr.Read(); 
            decimal currentbal = rdr.GetDecimal(6);
            CredBalance.Text = "RM" + currentbal.ToString();
            connection.Close();
           
        }

        private void btn_topUp_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString() == "Please Select..")
            {
                MessageBox.Show("Please choose a top up amount");
            }
            else
            {
                connection.Open();
                OleDbCommand cmd = new OleDbCommand();
                cmd.Connection = connection;
                cmd.CommandText = "select * from Users where Username='" + MainMenu.Login + "'";
                OleDbDataReader rdr = cmd.ExecuteReader();
                rdr.Read();

                decimal TopUp = decimal.Parse(comboBox1.SelectedItem.ToString());
                TopUp = TopUp + rdr.GetDecimal(6);
                rdr.Close();


                cmd.CommandText = "update Users set Credit_Balance='" + TopUp + "' where Username = '" + MainMenu.Login + "'";
                cmd.ExecuteNonQuery();
                MessageBox.Show("Top up successful!");
                CredBalance.Text = "RM" + TopUp;
                connection.Close();

            }
        }
    }
}
