﻿namespace IOOP_Assignment
{
    partial class Admin_Purchase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.box_Seller = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_Back = new System.Windows.Forms.Button();
            this.box_Purchase = new System.Windows.Forms.ListBox();
            this.box_Buyer = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // box_Seller
            // 
            this.box_Seller.Location = new System.Drawing.Point(15, 307);
            this.box_Seller.Name = "box_Seller";
            this.box_Seller.ReadOnly = true;
            this.box_Seller.Size = new System.Drawing.Size(126, 22);
            this.box_Seller.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 287);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "Seller :";
            // 
            // btn_Back
            // 
            this.btn_Back.Location = new System.Drawing.Point(200, 372);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(111, 53);
            this.btn_Back.TabIndex = 6;
            this.btn_Back.Text = "Back to Menu";
            this.btn_Back.UseVisualStyleBackColor = true;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // box_Purchase
            // 
            this.box_Purchase.FormattingEnabled = true;
            this.box_Purchase.ItemHeight = 16;
            this.box_Purchase.Location = new System.Drawing.Point(12, 54);
            this.box_Purchase.Name = "box_Purchase";
            this.box_Purchase.Size = new System.Drawing.Size(493, 212);
            this.box_Purchase.TabIndex = 5;
            this.box_Purchase.SelectedIndexChanged += new System.EventHandler(this.box_Purchase_SelectedIndexChanged);
            // 
            // box_Buyer
            // 
            this.box_Buyer.Location = new System.Drawing.Point(379, 307);
            this.box_Buyer.Name = "box_Buyer";
            this.box_Buyer.ReadOnly = true;
            this.box_Buyer.Size = new System.Drawing.Size(126, 22);
            this.box_Buyer.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(376, 287);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "Buyer :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // Admin_Purchase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(517, 479);
            this.Controls.Add(this.box_Buyer);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.box_Seller);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.box_Purchase);
            this.Name = "Admin_Purchase";
            this.Text = "Admin_Purchase";
            this.Load += new System.EventHandler(this.Admin_Purchase_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox box_Seller;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.ListBox box_Purchase;
        private System.Windows.Forms.TextBox box_Buyer;
        private System.Windows.Forms.Label label2;
    }
}