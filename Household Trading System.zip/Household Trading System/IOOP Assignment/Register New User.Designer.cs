﻿namespace IOOP_Assignment
{
    partial class Register_New_User
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.NewUser_box = new System.Windows.Forms.TextBox();
            this.NewPwd_box = new System.Windows.Forms.TextBox();
            this.NewName_box = new System.Windows.Forms.TextBox();
            this.ContNumb_box = new System.Windows.Forms.TextBox();
            this.NewEmail_box = new System.Windows.Forms.TextBox();
            this.NewRegister_btn = new System.Windows.Forms.Button();
            this.Back_btn = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.AccType_box = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(97, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Username :";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(101, 173);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Password :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(76, 241);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "Account Type:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(520, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 19);
            this.label4.TabIndex = 3;
            this.label4.Text = "Name :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(520, 176);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(130, 19);
            this.label5.TabIndex = 4;
            this.label5.Text = "Contact Number :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(520, 241);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 19);
            this.label6.TabIndex = 5;
            this.label6.Text = "E-mail :";
            // 
            // NewUser_box
            // 
            this.NewUser_box.Location = new System.Drawing.Point(188, 99);
            this.NewUser_box.Name = "NewUser_box";
            this.NewUser_box.Size = new System.Drawing.Size(267, 37);
            this.NewUser_box.TabIndex = 6;
            // 
            // NewPwd_box
            // 
            this.NewPwd_box.Location = new System.Drawing.Point(188, 170);
            this.NewPwd_box.Name = "NewPwd_box";
            this.NewPwd_box.Size = new System.Drawing.Size(267, 37);
            this.NewPwd_box.TabIndex = 7;
            // 
            // NewName_box
            // 
            this.NewName_box.Location = new System.Drawing.Point(583, 99);
            this.NewName_box.Name = "NewName_box";
            this.NewName_box.Size = new System.Drawing.Size(244, 37);
            this.NewName_box.TabIndex = 9;
            // 
            // ContNumb_box
            // 
            this.ContNumb_box.Location = new System.Drawing.Point(656, 170);
            this.ContNumb_box.Name = "ContNumb_box";
            this.ContNumb_box.Size = new System.Drawing.Size(171, 37);
            this.ContNumb_box.TabIndex = 10;
            // 
            // NewEmail_box
            // 
            this.NewEmail_box.Location = new System.Drawing.Point(583, 227);
            this.NewEmail_box.Name = "NewEmail_box";
            this.NewEmail_box.Size = new System.Drawing.Size(242, 37);
            this.NewEmail_box.TabIndex = 11;
            // 
            // NewRegister_btn
            // 
            this.NewRegister_btn.Location = new System.Drawing.Point(249, 323);
            this.NewRegister_btn.Name = "NewRegister_btn";
            this.NewRegister_btn.Size = new System.Drawing.Size(173, 44);
            this.NewRegister_btn.TabIndex = 12;
            this.NewRegister_btn.Text = "Register";
            this.NewRegister_btn.UseVisualStyleBackColor = true;
            this.NewRegister_btn.Click += new System.EventHandler(this.NewRegister_btn_Click);
            // 
            // Back_btn
            // 
            this.Back_btn.Location = new System.Drawing.Point(506, 323);
            this.Back_btn.Name = "Back_btn";
            this.Back_btn.Size = new System.Drawing.Size(173, 44);
            this.Back_btn.TabIndex = 13;
            this.Back_btn.Text = "Return to Main Menu";
            this.Back_btn.UseVisualStyleBackColor = true;
            this.Back_btn.Click += new System.EventHandler(this.Back_btn_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Adobe Fan Heiti Std B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label7.Location = new System.Drawing.Point(22, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(488, 25);
            this.label7.TabIndex = 15;
            this.label7.Text = "Please enter your details to complete the registration\r\n";
            // 
            // AccType_box
            // 
            this.AccType_box.FormattingEnabled = true;
            this.AccType_box.Items.AddRange(new object[] {
            "Buyer",
            "Seller"});
            this.AccType_box.Location = new System.Drawing.Point(188, 238);
            this.AccType_box.Name = "AccType_box";
            this.AccType_box.Size = new System.Drawing.Size(138, 27);
            this.AccType_box.TabIndex = 16;
            this.AccType_box.Text = "Choose one..";
            // 
            // Register_New_User
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(853, 400);
            this.Controls.Add(this.AccType_box);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Back_btn);
            this.Controls.Add(this.NewRegister_btn);
            this.Controls.Add(this.NewEmail_box);
            this.Controls.Add(this.ContNumb_box);
            this.Controls.Add(this.NewName_box);
            this.Controls.Add(this.NewPwd_box);
            this.Controls.Add(this.NewUser_box);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Adobe Fan Heiti Std B", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Register_New_User";
            this.Text = "Register New User";
            this.Load += new System.EventHandler(this.Register_New_User_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox NewUser_box;
        private System.Windows.Forms.TextBox NewPwd_box;
        private System.Windows.Forms.TextBox NewName_box;
        private System.Windows.Forms.TextBox ContNumb_box;
        private System.Windows.Forms.TextBox NewEmail_box;
        private System.Windows.Forms.Button NewRegister_btn;
        private System.Windows.Forms.Button Back_btn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox AccType_box;
    }
}