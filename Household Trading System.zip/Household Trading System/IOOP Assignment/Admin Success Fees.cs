﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment
{
    public partial class Admin_Success_Fees : Form
    {
        OleDbConnection connection = new OleDbConnection();
        public Admin_Success_Fees()
        {
            InitializeComponent();
            connection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=VelvetGoods2.mdb;";
        }

        private void Admin_Success_Fees_Load(object sender, EventArgs e)
        {
            connection.Open();
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = connection;
            cmd.CommandText = "select sum(Success_Fee) from Products where Status = 'Purchased'";
            string Fees = cmd.ExecuteScalar().ToString();
            lbl_Fees.Text = "RM" + Fees;
   
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
