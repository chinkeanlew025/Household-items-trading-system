﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment
{

    public partial class Products_Page : Form
    {
        private OleDbConnection connection = new OleDbConnection();


        public Products_Page()
        {
            InitializeComponent();
            connection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=VelvetGoods2.mdb;";
        }

        private void Products_Page_Load(object sender, EventArgs e)
        {
            btn_Buy.Enabled = false;

            connection.Open();
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = connection;
            cmd.CommandText = "select * from Products where Status = 'Selling'";
            OleDbDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                string Prod_ID = rdr.GetString(0);
                string Prod_Name = rdr.GetString(1);
                decimal Prod_Price = rdr.GetDecimal(3);
                string Prod_Seller = rdr.GetString(4);
                ProdList.Items.Add(Prod_ID + "\t" + Prod_Name.PadRight(16) + "\t\tRM" +Prod_Price.ToString("0.00").PadRight(10) + "\t" +Prod_Seller);
            }
            connection.Close();
            
            
        }

        private void ProdList_SelectedIndexChanged(object sender, EventArgs e)
        {
            btn_Buy.Enabled = true;

            //To Display product desciption in the label for selected item

            try
            {
                string Selecteditem = ProdList.SelectedItem.ToString().Substring(0, 5);

                connection.Open();
                OleDbCommand cmd = new OleDbCommand();
                cmd.Connection = connection;
                cmd.CommandText = "select * from Products where Product_ID='" + Selecteditem + "'";
                OleDbDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Descrip_label.Text = rdr.GetString(2);
                }
                connection.Close();
            }
            catch
            {
            
            }   


        }

        private void rbtn_Bedroom_CheckedChanged(object sender, EventArgs e)
        {
            Category("Bedroom");
        }

        private void rbtn_Bathroom_CheckedChanged(object sender, EventArgs e)
        {
            Category("Bathroom");
        }

        private void rbtn_Kitchen_CheckedChanged(object sender, EventArgs e)
        {
            Category("Kitchen");
        }

        private void rbtn_Electronics_CheckedChanged(object sender, EventArgs e)
        {
            Category("Electronics");
        }

        private void Category(string type)
        {
            ProdList.Items.Clear();
            connection.Open();
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = connection;
            cmd.CommandText = "select * from Products where Category ='" + type + "' and Status = 'Selling' ";
            OleDbDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                string Prod_ID = rdr.GetString(0);
                string Prod_Name = rdr.GetString(1);
                decimal Prod_Price = rdr.GetDecimal(3);
                string Prod_Seller = rdr.GetString(4);
                ProdList.Items.Add(Prod_ID + "\t" + Prod_Name.PadRight(16) + "\t\tRM" + Prod_Price.ToString("0.00").PadRight(10) + "\t" + Prod_Seller);
            }
            connection.Close();
        }

        private void rbtn_All_CheckedChanged(object sender, EventArgs e)
        {
            ProdList.Items.Clear();
            Products_Page_Load(null, null);
        }

        private void backToMenuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Buyer_Main_Page nf = new Buyer_Main_Page();
            this.Hide();
            nf.ShowDialog();
            
        }

        private void btn_AddItem_Click(object sender, EventArgs e)
        {
            try
            {
                string AddItem = ProdList.SelectedItems.ToString();

            }
            catch
            {
                MessageBox.Show("Please Select an Item you would like to add.");
            }
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void btn_Buy_Click(object sender, EventArgs e)
        {
            if(ProdList.SelectedItem != null)
            {

                connection.Open();
                string SelectedProd = ProdList.SelectedItem.ToString().Substring(0, 5);
                Order.Buy_ID = SelectedProd;

                OleDbCommand cmd = new OleDbCommand();
                cmd.Connection = connection;
                cmd.CommandText = "select * from Products where Product_ID='" + SelectedProd + "'";
                OleDbDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Order.Order_Name = rdr.GetString(1);
                    Order.Order_Price = rdr.GetDecimal(3);
                    Order.Seller = rdr.GetString(4);
                }
                connection.Close();

                Payment nf = new Payment();
                this.Hide();
                nf.ShowDialog();

            }
        }
    }
}
    public static class Order
    {
        public static string Buy_ID;
        public static decimal Order_Price;
        public static string Order_Name;
        public static string Seller;
    }
