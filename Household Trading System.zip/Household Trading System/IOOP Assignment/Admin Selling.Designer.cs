﻿namespace IOOP_Assignment
{
    partial class Admin_Selling
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.box_Sale = new System.Windows.Forms.ListBox();
            this.btn_Back = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.box_Descr = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // box_Sale
            // 
            this.box_Sale.FormattingEnabled = true;
            this.box_Sale.ItemHeight = 19;
            this.box_Sale.Location = new System.Drawing.Point(31, 35);
            this.box_Sale.Name = "box_Sale";
            this.box_Sale.Size = new System.Drawing.Size(389, 213);
            this.box_Sale.TabIndex = 0;
            this.box_Sale.SelectedIndexChanged += new System.EventHandler(this.box_Sale_SelectedIndexChanged);
            // 
            // btn_Back
            // 
            this.btn_Back.Location = new System.Drawing.Point(163, 379);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(111, 53);
            this.btn_Back.TabIndex = 1;
            this.btn_Back.Text = "Back to Menu";
            this.btn_Back.UseVisualStyleBackColor = true;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 268);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 19);
            this.label1.TabIndex = 3;
            this.label1.Text = "Product Description : ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // box_Descr
            // 
            this.box_Descr.Location = new System.Drawing.Point(31, 290);
            this.box_Descr.Multiline = true;
            this.box_Descr.Name = "box_Descr";
            this.box_Descr.ReadOnly = true;
            this.box_Descr.Size = new System.Drawing.Size(389, 55);
            this.box_Descr.TabIndex = 4;
            this.box_Descr.TextChanged += new System.EventHandler(this.box_Descr_TextChanged);
            // 
            // Admin_Selling
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(447, 444);
            this.Controls.Add(this.box_Descr);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.box_Sale);
            this.Font = new System.Drawing.Font("Adobe Fan Heiti Std B", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Admin_Selling";
            this.Text = "Items on Sale";
            this.Load += new System.EventHandler(this.Admin_Selling_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox box_Sale;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox box_Descr;
    }
}