﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment
{
    public partial class Add_New_Product : Form
    {
        OleDbConnection connection = new OleDbConnection();
        public Add_New_Product()
        {
            InitializeComponent();
            connection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=VelvetGoods2.mdb;";
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (box_Category.Text != "Please choose..")
            {
                string ProdName = box_ProdName.Text;
                string ProdDescr = box_Descr.Text;
                decimal ProdPrice = decimal.Parse(box_Price.Text);
                string ProdCategory = box_Category.SelectedItem.ToString();
                decimal perc = 0;
                if (ProdPrice >= 6 && ProdPrice <= 100)
                {
                    perc = 0.05M;
                }
                else if (ProdPrice >=101 && ProdPrice<= 1000)
                {
                    perc = 0.1M;
                }
                else if (ProdPrice >= 1001)
                {
                    perc = 0.15M;
                    
                }

                decimal Success_Fees = Decimal.Multiply(ProdPrice, perc);


                OleDbCommand cmd = new OleDbCommand();
                cmd.Connection = connection;
                cmd.CommandText = "insert into Products(Product_ID,Product_Name,Product_Description,Product_Price,Seller_Username,Success_Fee,[Status],[Category]) values ('DB1012','" + ProdName + "','" + ProdDescr + "','" + ProdPrice + "','" + MainMenu.Login + "','" + Success_Fees + "','Selling','" + ProdCategory + "'";
                cmd.ExecuteNonQuery();
                MessageBox.Show("Item Successfully added.");
            }
        }
        //(Product_ID,Product_Name,Product_Description,Product_Price,Seller_Username,Success_Fee,[Status],[Category])
        private void Add_New_Product_Load(object sender, EventArgs e)
        {
            connection.Open();
        }
    }
}
