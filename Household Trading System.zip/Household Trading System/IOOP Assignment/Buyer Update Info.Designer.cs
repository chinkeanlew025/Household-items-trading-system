﻿namespace IOOP_Assignment
{
    partial class Buyer_Update_Info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NewEmail_box = new System.Windows.Forms.TextBox();
            this.ContNumb_box = new System.Windows.Forms.TextBox();
            this.NewName_box = new System.Windows.Forms.TextBox();
            this.NewPwd_box = new System.Windows.Forms.TextBox();
            this.NewUser_box = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_Update = new System.Windows.Forms.Button();
            this.btn_Back = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // NewEmail_box
            // 
            this.NewEmail_box.Location = new System.Drawing.Point(517, 194);
            this.NewEmail_box.Name = "NewEmail_box";
            this.NewEmail_box.Size = new System.Drawing.Size(242, 37);
            this.NewEmail_box.TabIndex = 27;
            // 
            // ContNumb_box
            // 
            this.ContNumb_box.Location = new System.Drawing.Point(590, 137);
            this.ContNumb_box.Name = "ContNumb_box";
            this.ContNumb_box.Size = new System.Drawing.Size(171, 37);
            this.ContNumb_box.TabIndex = 26;
            // 
            // NewName_box
            // 
            this.NewName_box.Location = new System.Drawing.Point(517, 66);
            this.NewName_box.Name = "NewName_box";
            this.NewName_box.Size = new System.Drawing.Size(244, 37);
            this.NewName_box.TabIndex = 25;
            // 
            // NewPwd_box
            // 
            this.NewPwd_box.Location = new System.Drawing.Point(122, 137);
            this.NewPwd_box.Name = "NewPwd_box";
            this.NewPwd_box.Size = new System.Drawing.Size(267, 37);
            this.NewPwd_box.TabIndex = 24;
            // 
            // NewUser_box
            // 
            this.NewUser_box.Location = new System.Drawing.Point(122, 66);
            this.NewUser_box.Name = "NewUser_box";
            this.NewUser_box.Size = new System.Drawing.Size(267, 37);
            this.NewUser_box.TabIndex = 23;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(454, 208);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 19);
            this.label6.TabIndex = 22;
            this.label6.Text = "E-mail :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(454, 143);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(130, 19);
            this.label5.TabIndex = 21;
            this.label5.Text = "Contact Number :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(454, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 19);
            this.label4.TabIndex = 20;
            this.label4.Text = "Name :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 140);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 19);
            this.label2.TabIndex = 18;
            this.label2.Text = "Password :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 19);
            this.label1.TabIndex = 17;
            this.label1.Text = "Username :";
            // 
            // btn_Update
            // 
            this.btn_Update.Location = new System.Drawing.Point(133, 247);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(89, 54);
            this.btn_Update.TabIndex = 28;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = true;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // btn_Back
            // 
            this.btn_Back.Location = new System.Drawing.Point(288, 247);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(89, 54);
            this.btn_Back.TabIndex = 29;
            this.btn_Back.Text = "Back to Menu";
            this.btn_Back.UseVisualStyleBackColor = true;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(222, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(452, 19);
            this.label3.TabIndex = 30;
            this.label3.Text = "[On startup, fill the textbox with the default data in the database]";
            // 
            // Buyer_Update_Info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(829, 332);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.NewEmail_box);
            this.Controls.Add(this.ContNumb_box);
            this.Controls.Add(this.NewName_box);
            this.Controls.Add(this.NewPwd_box);
            this.Controls.Add(this.NewUser_box);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Adobe Fan Heiti Std B", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Buyer_Update_Info";
            this.Text = "Update Account Information";
            this.Load += new System.EventHandler(this.Buyer_Update_Info_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox NewEmail_box;
        private System.Windows.Forms.TextBox ContNumb_box;
        private System.Windows.Forms.TextBox NewName_box;
        private System.Windows.Forms.TextBox NewPwd_box;
        private System.Windows.Forms.TextBox NewUser_box;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.Label label3;
    }
}